# Kubernetes deployment — E-Commerce Billing Demo

## Requirements
- Docker Desktop (or alternative container build tool)
- kubectl and an accessible Kubernetes cluster
- A writable default StorageClass (or edit `k8s/pvc.yaml`)
- A container registry accessible to your cluster

## Build and push
```bash
docker build -t YOUR_REGISTRY/ecommerce-billing:v1 .
docker push YOUR_REGISTRY/ecommerce-billing:v1
```
Update `image:` in `k8s/deployment.yaml` to this exact image address.

## Deploy
```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/pvc.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl get pvc,pods,svc -n ecommerce-demo
kubectl rollout status deployment/billing-app -n ecommerce-demo
kubectl port-forward -n ecommerce-demo svc/billing-service 8080:80
```
Open http://localhost:8080 and place a test order. The invoice is displayed at `/invoice/<order_id>`.

## Troubleshoot
```bash
kubectl describe pvc billing-sqlite -n ecommerce-demo
kubectl describe pod -n ecommerce-demo -l app=billing-app
kubectl logs deployment/billing-app -n ecommerce-demo
```

## Notes
- SQLite is a demo-only choice; Deployment uses `replicas: 1` and `Recreate` to avoid multiple processes writing through different pods.
- The PVC needs a compatible StorageClass and permissions for uid/gid 10001.
- This app collects customer names, emails, and addresses; do not expose it publicly without authentication, rate limiting, TLS, and other production controls.
- For production, migrate to PostgreSQL/RDS/Cloud SQL and separately handle invoicing, backup, and tax compliance.
