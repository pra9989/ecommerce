from datetime import datetime, timezone
from decimal import Decimal
import os
import sqlite3
import uuid
from flask import Flask, abort, g, redirect, render_template, request, url_for

app = Flask(__name__)
DB_PATH = os.environ.get('SHOP_DB', os.path.join(os.path.dirname(__file__), 'orders.db'))
PRODUCTS = {
    'headphones': {'name': 'Wireless Headphones', 'price_paise': 150000, 'description': 'Bluetooth headphones'},
    'keyboard': {'name': 'Mechanical Keyboard', 'price_paise': 250000, 'description': 'USB mechanical keyboard'},
    'mouse': {'name': 'Wireless Mouse', 'price_paise': 79900, 'description': 'Ergonomic wireless mouse'},
}

def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop('db', None)
    if conn is not None:
        conn.close()

def init_db():
    with app.app_context():
        db().execute('''CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY, created_at TEXT NOT NULL, customer_name TEXT NOT NULL,
            email TEXT NOT NULL, address TEXT NOT NULL, product_id TEXT NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_price_paise INTEGER NOT NULL, total_paise INTEGER NOT NULL,
            payment_method TEXT NOT NULL, payment_status TEXT NOT NULL)''')
        db().commit()

@app.get('/healthz')
def healthz():
    db().execute('SELECT 1').fetchone()
    return {'status': 'ok'}

@app.get('/')
def shop():
    return render_template('index.html', products=PRODUCTS)

@app.post('/purchase')
def purchase():
    product_id = request.form.get('product_id', '')
    product = PRODUCTS.get(product_id)
    customer_name = request.form.get('customer_name', '').strip()
    email = request.form.get('email', '').strip()
    address = request.form.get('address', '').strip()
    try:
        quantity = int(request.form.get('quantity', '0'))
    except ValueError:
        quantity = 0
    if not product or not (1 <= quantity <= 10) or not customer_name or not email or '@' not in email or not address:
        return render_template('index.html', products=PRODUCTS, error='Enter a valid product, quantity (1–10), name, email and address.'), 400
    if any(len(value) > limit for value, limit in [(customer_name, 120), (email, 200), (address, 500)]):
        return render_template('index.html', products=PRODUCTS, error='One of the customer fields is too long.'), 400
    order_id = 'ORD-' + uuid.uuid4().hex[:12].upper()
    total = product['price_paise'] * quantity  # compute price server-side
    db().execute('''INSERT INTO orders
        (id, created_at, customer_name, email, address, product_id, product_name,
         quantity, unit_price_paise, total_paise, payment_method, payment_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (order_id, datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
         customer_name, email, address, product_id, product['name'], quantity,
         product['price_paise'], total, 'Cash on Delivery', 'PAYMENT DUE'))
    db().commit()
    return redirect(url_for('invoice', order_id=order_id), code=303)

@app.get('/invoice/<order_id>')
def invoice(order_id):
    order = db().execute('SELECT * FROM orders WHERE id = ?', (order_id,)).fetchone()
    if order is None:
        abort(404)
    return render_template('invoice.html', order=order)

@app.template_filter('rupees')
def rupees(paise):
    return f'{Decimal(paise) / 100:,.2f}'

if __name__ == '__main__':
    init_db()
    app.run(host='127.0.0.1', port=5000, debug=False)
