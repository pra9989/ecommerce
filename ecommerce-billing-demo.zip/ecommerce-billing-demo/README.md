# E-commerce purchase + billing demo (no payment gateway)

## Windows setup
1. Extract this folder, for example to `C:\Projects\ecommerce-billing-demo`.
2. Open CMD in the directory.
3. `python -m venv venv`
4. `venv\Scripts\activate`
5. `python -m pip install -r requirements.txt`
6. `python app.py`
7. Open `http://127.0.0.1:5000`
8. Select a product, quantity, enter customer information and select **Place Order & Generate Bill**.
9. On the bill page choose **Print / Save as PDF** and select **Save as PDF** in the browser's print dialog.

Orders are written to local SQLite `orders.db` automatically. Each bill has a unique order ID and can be revisited at `/invoice/<order-id>`.

## Replacing the previous Razorpay application
Stop the old app with Ctrl+C. **Keep the old folder as backup**; use this demo in a separate folder. No `.env`, Razorpay keys, webhook or domain is needed. The server still uses port 5000, so stop the previous server first.

## Important
- Payment type: Cash on Delivery. The bill is **PAYMENT DUE**, not PAID.
- This demo has no login, customer data authorization, invoice access control, inventory reservation, shipping/tax calculation or email delivery; do not expose it publicly.
- The order bill is **not** a legally compliant GST tax invoice. For real business use, configure the applicable seller details, GST/taxes, numbering and compliance requirements.
