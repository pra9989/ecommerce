# Flask + Razorpay Test Checkout

Demo only: uses local SQLite storage and does not implement login, inventory, refunds, or fulfillment.

## Setup
1. Create Razorpay Test Mode keys in your dashboard.
2. `python -m venv .venv`
3. Activate: macOS/Linux `source .venv/bin/activate`; Windows `.venv\\Scripts\\activate`
4. `pip install -r requirements.txt`
5. Copy `.env.example` to `.env`, replace key id, key secret and webhook secret.
6. `python app.py`
7. Browse `http://127.0.0.1:5000` and click Buy Now.

Razorpay has mock success/failure flows with test keys. Use auto-capture and test the `captured` state.

## Webhooks
To test server-to-server payment confirmations, make your `/webhook` HTTPS route publicly reachable and register it in the Razorpay dashboard in **Test Mode** for the `payment.captured` event. Set the exact same webhook secret in your dashboard and `.env`. Localhost cannot directly receive external webhook calls. Keep the webhook secret separate from your API key secret.

## Security and production notes
- Do not commit `.env` or leak Razorpay key secret to clients.
- Protect `/order/<order_id>` with customer authentication/authorization.
- Authenticate cart ownership and calculate price, shipping, discounts, tax and inventory on the backend.
- Move to PostgreSQL or another durable DB and transactional outbox/queue for reliable fulfillment.
- Add order idempotency and prevent duplicate checkouts/orders.
- Verify signatures, order ids, currency, amounts, payment statuses, and webhook authenticity.
- Respond to webhook retries idempotently; handle missing/out-of-order events and refunds.
- Configure HTTPS, rate limits, observability, and reconciliation before live use.
