import os
import sqlite3
import hmac
import hashlib
import json
import uuid

from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv
import razorpay

load_dotenv()
app = Flask(__name__)
KEY_ID = os.environ["RAZORPAY_KEY_ID"]
KEY_SECRET = os.environ["RAZORPAY_KEY_SECRET"]
WEBHOOK_SECRET = os.environ.get("RAZORPAY_WEBHOOK_SECRET", "")
client = razorpay.Client(auth=(KEY_ID, KEY_SECRET))
DB_PATH = os.path.join(os.path.dirname(__file__), "orders.db")

# Product prices are owned by the server, never accepted from the browser.
PRODUCTS = {
    "headphones": {"name": "Wireless Headphones", "amount": 150000},
    "keyboard": {"name": "Mechanical Keyboard", "amount": 250000},
}


def db():
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    return connection


def setup_db():
    with db() as connection:
        connection.execute("""CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY,
            razorpay_order_id TEXT UNIQUE NOT NULL,
            product_id TEXT NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING',
            payment_id TEXT
        )""")
        connection.execute("""CREATE TABLE IF NOT EXISTS webhook_events (
            event_id TEXT PRIMARY KEY
        )""")


def mark_paid(order_id, payment_id, amount):
    # Caller must have verified the event or payment with Razorpay.
    with db() as connection:
        order = connection.execute(
            "SELECT * FROM orders WHERE razorpay_order_id = ?", (order_id,)
        ).fetchone()
        if not order or order["amount"] != amount:
            return False
        if order["status"] == "PAID":
            return order["payment_id"] == payment_id
        connection.execute(
            "UPDATE orders SET status = 'PAID', payment_id = ? WHERE razorpay_order_id = ? AND status = 'PENDING'",
            (payment_id, order_id),
        )
        return True


@app.get("/")
def home():
    return render_template("index.html", products=PRODUCTS)


@app.post("/create-order")
def create_order():
    data = request.get_json(silent=True) or {}
    product_id = data.get("product_id")
    product = PRODUCTS.get(product_id)
    if not product:
        return jsonify(error="Unknown product"), 400

    local_id = uuid.uuid4().hex
    try:
        rp_order = client.order.create({
            "amount": product["amount"],
            "currency": "INR",
            "receipt": local_id[:40],
        })
    except Exception:
        app.logger.exception("Failed to create payment order")
        return jsonify(error="Unable to create order"), 502
    with db() as connection:
        connection.execute(
            "INSERT INTO orders (id, razorpay_order_id, product_id, amount, status) VALUES (?, ?, ?, ?, 'PENDING')",
            (local_id, rp_order["id"], product_id, product["amount"]),
        )
    return jsonify(key=KEY_ID, order_id=rp_order["id"], amount=product["amount"],
                   currency="INR", product=product["name"])


@app.post("/verify-payment")
def verify_payment():
    data = request.get_json(silent=True) or {}
    order_id = data.get("razorpay_order_id", "")
    payment_id = data.get("razorpay_payment_id", "")
    signature = data.get("razorpay_signature", "")
    if not all(isinstance(x, str) and x for x in (order_id, payment_id, signature)):
        return jsonify(error="Missing payment fields"), 400
    with db() as connection:
        order = connection.execute(
            "SELECT * FROM orders WHERE razorpay_order_id = ?", (order_id,)
        ).fetchone()
    if not order:
        return jsonify(error="Unknown order"), 404
    try:
        # Signature is based on the backend-stored order id.
        client.utility.verify_payment_signature({
            "razorpay_order_id": order["razorpay_order_id"],
            "razorpay_payment_id": payment_id,
            "razorpay_signature": signature,
        })
        payment = client.payment.fetch(payment_id)
    except Exception:
        app.logger.exception("Payment verification failed")
        return jsonify(error="Payment verification failed"), 400
    if (payment.get("order_id") != order_id or
            payment.get("amount") != order["amount"] or
            payment.get("currency") != "INR"):
        return jsonify(error="Payment does not match order"), 400
    if payment.get("status") != "captured":
        return jsonify(status="PENDING", message="Payment is not captured yet"), 202
    if not mark_paid(order_id, payment_id, order["amount"]):
        return jsonify(error="Order conflict"), 409
    return jsonify(status="PAID", order_id=order_id)


@app.get("/order/<order_id>")
def order_status(order_id):
    with db() as connection:
        order = connection.execute(
            "SELECT id, product_id, amount, status FROM orders WHERE razorpay_order_id = ?",
            (order_id,),
        ).fetchone()
    if not order:
        return jsonify(error="Unknown order"), 404
    # Demo only: protect this endpoint with customer auth in production.
    return jsonify(dict(order))


@app.post("/webhook")
def webhook():
    if not WEBHOOK_SECRET:
        return jsonify(error="Webhook not configured"), 503
    raw = request.get_data()
    received = request.headers.get("X-Razorpay-Signature", "")
    expected = hmac.new(WEBHOOK_SECRET.encode(), raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received):
        return jsonify(error="Invalid webhook signature"), 400
    event = json.loads(raw)
    event_id = request.headers.get("x-razorpay-event-id", "")
    if not event_id:
        return jsonify(error="Missing webhook event id"), 400
    if event.get("event") == "payment.captured":
        entity = event.get("payload", {}).get("payment", {}).get("entity", {})
        order_id = entity.get("order_id")
        payment_id = entity.get("id")
        amount = entity.get("amount")
        if order_id and payment_id and isinstance(amount, int):
            # Store dedupe key and status update in one transaction.
            with db() as connection:
                exists = connection.execute("SELECT 1 FROM webhook_events WHERE event_id = ?", (event_id,)).fetchone()
                if exists:
                    return jsonify(ok=True)
                order = connection.execute("SELECT * FROM orders WHERE razorpay_order_id = ?", (order_id,)).fetchone()
                if order and order["amount"] == amount and (
                    order["status"] == "PENDING" or order["payment_id"] == payment_id
                ):
                    connection.execute("UPDATE orders SET status = 'PAID', payment_id = ? WHERE razorpay_order_id = ? AND status = 'PENDING'", (payment_id, order_id))
                connection.execute("INSERT INTO webhook_events (event_id) VALUES (?)", (event_id,))
    return jsonify(ok=True)


setup_db()
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
